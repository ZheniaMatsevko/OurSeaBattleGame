package com.mygdx.game;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.InputProcessor;
import com.badlogic.gdx.ScreenAdapter;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.graphics.g2d.freetype.FreeTypeFontGenerator;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.ImageButton;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.scenes.scene2d.utils.TextureRegionDrawable;
import com.badlogic.gdx.utils.ScreenUtils;
import com.badlogic.gdx.utils.viewport.ScreenViewport;

public class PutShipsScreen extends ScreenAdapter implements InputProcessor {
    SeaBattleGame game;
    private SpriteBatch batch;
    private Sprite sprite;
    private Stage stage;
    private BitmapFont font;
    private ImageButton putAgainButton;
    private TextButton playButton;
    private Skin skin;
    private PlayGround playGround;

    public PutShipsScreen(SeaBattleGame game) {
        skin = new Skin(Gdx.files.internal("uiskin.json"));
        this.game = game;
        FreeTypeFontGenerator generator = new FreeTypeFontGenerator(Gdx.files.internal("Zyana.ttf"));
        FreeTypeFontGenerator.FreeTypeFontParameter parameter = new FreeTypeFontGenerator.FreeTypeFontParameter();
        parameter.size = 30;
        parameter.color = Color.BLACK;
        parameter.borderWidth = 1;
        parameter.borderColor = Color.GRAY;
        font = generator.generateFont(parameter);
        stage = new Stage(new ScreenViewport());
        playGround = new PlayGround(10,10);
        batch = new SpriteBatch();
        sprite = new Sprite(new Texture(Gdx.files.internal("putships.jpg")));
        sprite.setSize(Gdx.graphics.getWidth(), Gdx.graphics.getHeight());
        Texture myTexture = new Texture(Gdx.files.internal("again.png"));
        TextureRegion myTextureRegion = new TextureRegion(myTexture);
        TextureRegionDrawable myTexRegionDrawable = new TextureRegionDrawable(myTextureRegion);
        putAgainButton = new ImageButton(myTexRegionDrawable);
        putAgainButton.setPosition(Gdx.graphics.getWidth()-putAgainButton.getWidth()-60,Gdx.graphics.getHeight()-putAgainButton.getHeight()-80);
        playButton = new TextButton("PLAY", skin);
        playButton.getLabel().setFontScale(1,1);
        playButton.setPosition(Gdx.graphics.getWidth()-playButton.getWidth()-30,putAgainButton.getY()-putAgainButton.getHeight()-20);
        stage.addActor(putAgainButton);
        stage.addActor(playGround);
        stage.addActor(playButton);
        Gdx.input.setInputProcessor(this);
    }

    @Override
    public void render(float delta) {
        String text = "Put ships on the field";
        ScreenUtils.clear(0, 0, 0, 1);
        batch.begin();
        sprite.draw(batch);
        font.draw(batch,text,11,30);
        batch.end();
        stage.act(Gdx.graphics.getDeltaTime());
        stage.draw();
    }

    @Override
    public boolean keyDown(int keycode) {
        return false;
    }

    @Override
    public boolean keyUp(int keycode) {
        return false;
    }

    @Override
    public boolean keyTyped(char character) {
        return false;
    }

    public void putRandomBoats(){

    }

    @Override
    public boolean touchDown(int screenX, int screenY, int pointer, int button) {
        Vector2 coord = stage.screenToStageCoordinates(new Vector2((float)screenX,(float) screenY));
        Actor hitActor = playGround.getStage().hit(coord.x,coord.y,true);
        if(hitActor==null)
            System.out.println("no");
        if(hitActor!=null) {
            System.out.println("yes");
            Cell ace = (Cell) playGround.getGroup().findActor(hitActor.getName());
            ace.changeColor();
        }
        return true;
    }

    @Override
    public boolean touchUp(int screenX, int screenY, int pointer, int button) {
        return false;
    }

    @Override
    public boolean touchDragged(int screenX, int screenY, int pointer) {
        return false;
    }

    @Override
    public boolean mouseMoved(int screenX, int screenY) {
        return false;
    }

    @Override
    public boolean scrolled(float amountX, float amountY) {
        return false;
    }
}
