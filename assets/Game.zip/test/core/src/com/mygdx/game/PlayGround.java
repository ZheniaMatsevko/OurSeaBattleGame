package com.mygdx.game;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.InputProcessor;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Batch;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.scenes.scene2d.*;
import com.badlogic.gdx.scenes.scene2d.ui.Image;

import java.awt.*;
import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;


public class PlayGround extends Actor  {
    private int numberOfCellsInRow;
    private Group group;
    private Stage stage;
    private Cell[] cells;
    private Cell[][] cellsGround;
    private Sprite sprite;
    private Sprite[] sprites;
    private Boat[] boats;
    public PlayGround(int numberOfCellsInRow, int numberOfBoats){
        this.numberOfCellsInRow = numberOfCellsInRow;

        group = new Group();
        stage = new Stage();
        /*cellsGround = new Cell[numberOfCellsInRow][numberOfCellsInRow];
        float x = 10, y=Gdx.graphics.getHeight()-10;
        for(int i=0;i<numberOfCellsInRow;i++){
            for(int j=0;j<numberOfCellsInRow;j++){
                cellsGround[i][j] = new Cell();
                if(i==0 && j==0){
                    y-=cellsGround[i][j].getHeight();
                    cellsGround[i][j].setPosition(x,y);
                }else if(j==0){
                    cellsGround[i][j].setPosition(x,y);
                }else{
                    x=cellsGround[i][j-1].getX()+cellsGround[i][j-1].getWidth();
                    cellsGround[i][j].setPosition(x,y);
                }
                if(j==numberOfCellsInRow-1){
                    x=10;
                    y=cellsGround[i][j-1].getY()-cellsGround[i][j-1].getHeight();
                }
                cellsGround[i][j].setName(String.valueOf(i));
                group.addActor(cellsGround[i][j]);
            }
        }*/

       /* boats = new Boat[numberOfBoats];
        sprites = new Sprite[numberOfBoats];
        for(int i=0;i<numberOfBoats;i++){
            if(i==0){
                boats[i] = new Boat(4,Boat.getBoatImage(4));
            } else if(i>1 && i<4)
                boats[i] = new Boat(3,Boat.getBoatImage(3));
            else if(i>3 && i<7)
                boats[i] = new Boat(2,Boat.getBoatImage(2));
            else
                boats[i] = new Boat(1,Boat.getBoatImage(1));
            stage.addActor(boats[i]);
        }*/

        cells = new Cell[numberOfCellsInRow*numberOfCellsInRow];
        float x = 10;
        float y=Gdx.graphics.getHeight()-10;
        for(int i=0;i<cells.length;i++){
            cells[i] = new Cell();
            if(i==0){
                y-=cells[i].getHeight();
                cells[i].setPosition(x,y);
            }
            else if(i!=0 && i%numberOfCellsInRow!=0){
                x=cells[i-1].getX()+cells[i-1].getWidth();
                cells[i].setPosition(x,y);
            }
            else if(i%numberOfCellsInRow==0){
                x=10;
                y=cells[i-1].getY()-cells[i-1].getHeight();
                cells[i].setPosition(x,y);
            }
            cells[i].setName(String.valueOf(i));
            group.addActor(cells[i]);
        }
        setBounds(0,Gdx.graphics.getHeight(),cells[numberOfCellsInRow*numberOfCellsInRow-1].getX()+cells[numberOfCellsInRow*numberOfCellsInRow-1].getWidth(),Gdx.graphics.getHeight()-50);
        setTouchable(Touchable.enabled);
        /*for(int i=0;i<numberOfCellsInRow;i++){
            if(i==0)
                sprites[i] = new Sprite(new Texture(Gdx.files.internal("boat4.png")));
            else if(i>1 && i<4)
                sprites[i] = new Sprite(new Texture(Gdx.files.internal("boat3.png")));
            else if(i>3 && i<7)
                sprites[i] = new Sprite(new Texture(Gdx.files.internal("boat2.png")));
            else
                sprites[i] = new Sprite(new Texture(Gdx.files.internal("boat.png")));
        }*/
        //sprite = new Sprite(new Texture(Gdx.files.internal("boat4.png")));
        //putRandomBoats();
        stage.addActor(group);

    }

    public void putRandomBoats(){
        /*Random rand = new Random();
        int originX,originY,n;
        int direction=0;
        boolean canLocate = false;
        for(int b=0;b<numberOfCellsInRow;b++){
            do{
                originX = ThreadLocalRandom.current().nextInt(0, numberOfCellsInRow);
                originY = ThreadLocalRandom.current().nextInt(0, numberOfCellsInRow);
                while(cellsGround[originX][originY].getIsTaken() || (originX-1>=0 && cellsGround[originX-1][originY].getIsTaken()) || (originY-1>=0 && cellsGround[originX][originY-1].getIsTaken()) || (originY-1>=0 && originX-1>=0 && cellsGround[originX-1][originY-1].getIsTaken()) || (originY+1<10 && cellsGround[originX][originY+1].getIsTaken()) || (originX+1<10 && cellsGround[originX+1][originY].getIsTaken()) || (originX+1<10 && originY+1<10 && cellsGround[originX+1][originY+1].getIsTaken()) || (originX+1<10 && originY-1>=0 && cellsGround[originX+1][originY-1].getIsTaken()) || (originY+1<10 && originX-1>=0 && cellsGround[originX-1][originY+1].getIsTaken())){
                    originX = ThreadLocalRandom.current().nextInt(0, numberOfCellsInRow);
                    originY = ThreadLocalRandom.current().nextInt(0, numberOfCellsInRow);
                }
                if(boats[b].getSize()==1)
                    break;
                direction = ThreadLocalRandom.current().nextInt(0, 2);
                if(direction==0){
                    int count = boats[b].getSize() + 1;
                    int i = originX,j = originY;
                    while(j<numberOfCellsInRow && !cellsGround[i][j].getIsTaken() && count>0){
                        j++;
                        count--;
                    }
                    j=originY-1;
                    while(count>0 && ){

                    }
                    /*while((n+1)<100&&cells[n].getY()==cells[n+1].getY() && count>0){
                        n+=1;
                        count--;
                    }
                    while(count>0){
                        origin--;
                        count--;
                    }*/

                /*}else{
                    for (int i=0;i<numberOfCellsInRow;i++){
                        for(int j=0;j<numberOfCellsInRow;j++){

                        }
                    }
                }

            }while(!canLocate);
            if(boats[b].getSize()==1){
                sprite.setPosition(cellsGround[originX][originY].getX(),cellsGround[originX][originY].getY());
            }
        }*/





        /*Random rand = new Random();
        int origin, direction,count,n;
        for (int i=0;i<numberOfCellsInRow;i++){
            origin = ThreadLocalRandom.current().nextInt(0, numberOfCellsInRow*numberOfCellsInRow);
            direction = ThreadLocalRandom.current().nextInt(0, 2);
            count = 3;
            n = origin;
            switch(direction){
                case 0:
                    while((n+1)<100&&cells[n].getY()==cells[n+1].getY() && count>0){
                        n+=1;
                        count--;
                    }
                    while(count>0){
                        origin--;
                        count--;
                    }
                    break;
                case 1:
                    sprite.setRotation(90);
                    while((n+numberOfCellsInRow)<100 && cells[n].getX()==cells[n+numberOfCellsInRow].getX() && count>0){
                        n+=numberOfCellsInRow;
                        count--;
                    }
                    while(count>0){
                        origin-=numberOfCellsInRow;
                        count--;
                    }
                    break;
            }
            System.out.println(cells[origin].getName() + " " + origin);
            boolean canLocate = true;
            if(i>0){
                for(int j=0;j<i;j++){
                    switch (direction){
                        case 0:
                            if(cells[origin].getX()+sprites[i].getWidth()==sprites[j].getX() && cells[origin].getY()==sprites[j].getY()){
                                canLocate=false;
                            }
                            break;
                        case 1:
                            if(cells[origin].getX()==sprites[j].getX() && cells[origin].getY()+sprites[i].getHeight()==sprites[j].getY()){
                                canLocate=false;
                            }
                            break;
                    }
                   if(!canLocate) break;
                }
            }
            if(direction==2 ){
                sprite.setPosition(cells[origin].getX()-sprite.getWidth()/8*3,cells[origin].getY() - sprite.getHeight()/8*3 - cells[origin].getHeight()-5);
            }else{
                sprite.setPosition(cells[origin].getX(),cells[origin].getY());
            }
        }

        /*origin = ThreadLocalRandom.current().nextInt(0, numberOfCellsInRow*numberOfCellsInRow);
        direction = ThreadLocalRandom.current().nextInt(0, 4);
        count = 3;
        n = origin;
        direction = 2;
        switch(direction){
            case 0:
                while((n+1)<100&&cells[n].getY()==cells[n+1].getY() && count>0){
                    n+=1;
                    count--;
                }
                while(count>0){
                    origin--;
                    count--;
                }
                break;
            case 1:
                while((n-1)>=0 && cells[n].getY()==cells[n-1].getY() && count>0){
                    n-=1;
                    count--;
                }
                origin=n;
                break;
            case 2:
                sprite.setRotation(90);
                while((n+numberOfCellsInRow)<100 && cells[n].getX()==cells[n+numberOfCellsInRow].getX() && count>0){
                    n+=numberOfCellsInRow;
                    count--;
                }
                while(count>0){
                    origin-=numberOfCellsInRow;
                    count--;
                }
                break;
            case 3:
                sprite.setRotation(90);
                while((n-numberOfCellsInRow)>=0 && cells[n].getX()==cells[n-numberOfCellsInRow].getX() && count>0){
                    n-=numberOfCellsInRow;
                    count--;
                }
                while(count>0){
                    origin+=numberOfCellsInRow;
                    count--;
                }
                break;
        }
        System.out.println(cells[origin].getName() + " " + origin);
        if(direction==2 ){
            sprite.setPosition(cells[origin].getX()-sprite.getWidth()/8*3,cells[origin].getY() - sprite.getHeight()/8*3 - cells[origin].getHeight()-5);
        }else  if(direction==3 ){
            sprite.setPosition(cells[origin].getX(),cells[origin].getY());
            //sprite.setPosition(cells[origin].getX()-sprite.getWidth()/8*3,cells[origin].getY() + sprite.getHeight()/8*3 + cells[origin].getHeight()+5);
        }else {
            sprite.setPosition(cells[origin].getX(),cells[origin].getY());
        }

        /*
        cells[origin].changeColor();
        int direction = ThreadLocalRandom.current().nextInt(0, 4);
        int count = 3;
        int n = origin;
        switch(direction){
            case 0:
                while(cells[n].getY()==cells[n+1].getY() && count>0){
                    n+=1;
                    cells[n].changeColor();
                    count--;
                }
                while(count>0){
                    origin--;
                    cells[origin].changeColor();
                    count--;
                }
                break;
            case 1:
                while(n>=0 && cells[n].getY()==cells[n-1].getY() && count>0){
                    n-=1;
                    cells[n].changeColor();
                    count--;
                }
                while(count>0){
                    origin++;
                    cells[origin].changeColor();
                    count--;
                }
                break;
            case 2:
                while(n>=0 && cells[n].getX()==cells[n+7].getX() && count>0){
                    n+=7;
                    cells[n].changeColor();
                    count--;
                }
                while(count>0){
                    origin-=7;
                    cells[origin].changeColor();
                    count--;
                }
                break;
            case 3:
                while(n>=0 && cells[n].getX()==cells[n-7].getX() && count>0){
                    n-=7;
                    cells[n].changeColor();
                    count--;
                }
                while(count>0){
                    origin+=7;
                    cells[origin].changeColor();
                    count--;
                }
                break;
        }*/
    }

    @Override
    public void draw(Batch batch, float parentAlpha) {
        stage.act(Gdx.graphics.getDeltaTime());
        stage.draw();
        /*for(int i=0;i<numberOfCellsInRow;i++)
            sprites[i].draw(batch);*/
        //sprite.draw(batch);
    }
    public Stage getStage(){
        return stage;
    }

    @Override
    public void act(float delta) {
        super.act(delta);
    }
    public Group getGroup(){
        return group;
    }


}
      /*Image cell1 = new Image(new Texture(Gdx.files.internal("square.png")));
        Image cell2 = new Image(new Texture(Gdx.files.internal("square.png")));
        Image cell3 = new Image(new Texture(Gdx.files.internal("square.png")));
        Image cell4 = new Image(new Texture(Gdx.files.internal("square.png")));
        Image cell5 = new Image(new Texture(Gdx.files.internal("square.png")));
        Image cell6 = new Image(new Texture(Gdx.files.internal("square.png")));
        Image cell7 = new Image(new Texture(Gdx.files.internal("square.png")));
        Image cell8 = new Image(new Texture(Gdx.files.internal("square.png")));
        Image cell9 = new Image(new Texture(Gdx.files.internal("square.png")));
        Image cell10 = new Image(new Texture(Gdx.files.internal("square.png")));
        Image cell11 = new Image(new Texture(Gdx.files.internal("square.png")));
        Image cell12 = new Image(new Texture(Gdx.files.internal("square.png")));
        Image cell13 = new Image(new Texture(Gdx.files.internal("square.png")));
        Image cell14 = new Image(new Texture(Gdx.files.internal("square.png")));
        Image cell15 = new Image(new Texture(Gdx.files.internal("square.png")));
        Image cell16 = new Image(new Texture(Gdx.files.internal("square.png")));*/
      /*cell1.setPosition(10,Gdx.graphics.getHeight()-cell1.getHeight()-10);
        cell2.setPosition(cell1.getX()+cell1.getWidth(),cell1.getY());
        cell3.setPosition(cell2.getX()+cell2.getWidth(),cell1.getY());
        cell4.setPosition(cell3.getX()+cell3.getWidth(),cell1.getY());
        cell5.setPosition(10,cell1.getY()-cell1.getHeight());
        cell6.setPosition(cell5.getX()+cell5.getWidth(),cell5.getY());
        cell7.setPosition(cell6.getX()+cell6.getWidth(),cell5.getY());
        cell8.setPosition(cell7.getX()+cell7.getWidth(),cell5.getY());

        /*group.addActor(cell1);
        group.addActor(cell2);
        group.addActor(cell3);
        group.addActor(cell4);
        group.addActor(cell5);
        group.addActor(cell6);
        group.addActor(cell7);
        group.addActor(cell8);*/